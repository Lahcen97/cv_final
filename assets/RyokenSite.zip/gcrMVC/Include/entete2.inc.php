<!DOCTYPE html> <html lang="fr">
    <head>
        <meta charset="UTF-8" /> 
        <link rel="stylesheet" href="./Styles/gcr2.css" />
        <title>GSB : GCR Gestion des comptes rendus de visite</title>
    </head> 
    <body> 

