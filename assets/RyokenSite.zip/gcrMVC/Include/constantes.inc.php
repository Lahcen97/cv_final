<?php
define('INCLUDES_PIED','./include/pied.inc.php');
//connexion

define('PAGE_IDENTIFICATION','./Identif.php');
define('AFFICHAGE_IDENTIFICATION',20);
define('TRAITEMENT_IDENTIFICATION',21);
define('DECONNEXION_IDENTIFICATION',22);


//formulaire praticien
define('PAGE_FORM_PRATICIEN','./formPRATICIEN.php');
define('PRATICIEN_AFFICHER_LISTE',30); // Affichage de la liste permettant de choisir un praticien.
define('PRATICIEN_AFFICHER_FICHE',31);

//formulaire medicament
define('PAGE_FORM_MEDICAMENT','./formMEDICAMENT.php');
define('MEDICAMENT_AFFICHER_LISTE_FAMILLE',50);
define('MEDICAMENT_AFFICHER_LISTE_NOM',51);
define('MEDICAMENT_AFFICHER_LISTE_FICHE',52);

?>


        
        
        
       
