<?php
require_once '../gcrMVC/Include/Bibliotheque01.inc.php';
require_once '../gcrMVC/Include/constantes.inc.php';
require_once '../gcrMVC/modèle/SourceDonnees.inc.php';
require_once '../gcrMVC/controle/Securite.inc.php';

if (!isset($_REQUEST['action'])) 
{ // Démarrage de l'application.
    $_REQUEST['action'] = AFFICHAGE_IDENTIFICATION;
} else 
{   
    estSessionUtilisateurOuverte() == true ? "" : $_REQUEST['action'] = AFFICHAGE_IDENTIFICATION;
}

   

switch ($_REQUEST['action']) 
{
    case AFFICHAGE_IDENTIFICATION:
        require_once './affichage/Identif.php';
        break;
    
    case TRAITEMENT_IDENTIFICATION:
        require_once './affichage/Identif.php';
        break;

    case PRATICIEN_AFFICHER_LISTE:
        require_once './affichage/formPRATICIEN.php';
        break;

    case PRATICIEN_AFFICHER_FICHE:
        require_once './affichage/formPRATICIEN.php';
        break;

    case PAGE_FORM_MEDICAMENT:
        require_once './affichage/formMEDICAMENT.php';
        break;
    case MEDICAMENT_AFFICHER_LISTE_FAMILLE:
        require_once './affichage/formMEDICAMENT.php';
        break;
    case MEDICAMENT_AFFICHER_LISTE_NOM:
        require_once './affichage/formMEDICAMENT.php';
        break;

    case MEDICAMENT_AFFICHER_LISTE_FICHE:
        require_once './affichage/formMedicament.php';
        break;
    case 60:
        require_once './formVISITEUR.html';
        break;
    case 324:
        destruction();
        header("location: index.php?action=" . AFFICHAGE_IDENTIFICATION);
}


require_once './Include/pied.inc.php';
?>



