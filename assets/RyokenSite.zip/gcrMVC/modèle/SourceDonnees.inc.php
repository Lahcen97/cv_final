<?php

function SGBDConnect() {
    try {
        $connexion = new PDO('mysql:host=localhost;dbname=gsb', 'root','');
        $connexion->query('SET NAMES UTF8');
        $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo 'erreur !:' . $e->getMessage() . '<br/>';
        exit();
    }
    return $connexion;
}

function getListePraticiens() {
    $requete = 'SELECT PRA_NUM, concat(PRA_NOM," ",PRA_PRENOM) FROM praticien order by PRA_NOM';
    $resultat = SGBDConnect()->query($requete);

    return $resultat;
}

function getListeFamilleMedicament() {
    $requete = 'SELECT FAM_CODE, FAM_LIBELLE FROM famille order by FAM_LIBELLE';
    $resultat = SGBDConnect()->query($requete);
    return $resultat;
}

function getListeMedicament($famille) {
    $requete = 'SELECT MED_CODE, MED_NOM FROM medicament where MED_FAMILLE="' . $famille . '" order by MED_NOM';
    $resultat = SGBDConnect()->query($requete);
    return $resultat;
}

function existeCompteVisiteur($VIS_CODE, $MDP) {
    $requete = 'select visiteur.VIS_CODE, visiteur.VIS_PASSE '
            . ' FROM visiteur '
            . ' WHERE VIS_CODE =\'' . $VIS_CODE . '\''
            . ' and VIS_PASSE=\'' . $MDP . '\'';
    $resultat = SGBDConnect()->query($requete);

    return $resultat->rowCount();
}

function GetInfoVisiteur($VIS_CODE)
{
    $requete = 'select concat(visiteur.VIS_NOM," ",visiteur.VIS_PRENOM),travail.TRA_ROLE, region.REG_NOM FROM visiteur inner join travail on visiteur.VIS_CODE=travail.TRA_VIS inner join region on region.REG_CODE=travail.TRA_REG ' 
            . ' WHERE VIS_CODE =\'' . $VIS_CODE . '\'';
    
    $resultat = SGBDConnect()->query($requete);
    
    return $resultat;
}

function getListeInfosMedicament($CODE_MED) {
    $requete = 'select MED_CODE , MED_NOM , MED_LABO, MED_FAMILLE , MED_COMPO , MED_EFFETS , MED_CONTREINDIC FROM medicament where MED_CODE="' . $CODE_MED . '" order by MED_NOM ';
    $resultat = SGBDConnect()->query($requete);
    $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();

    echo formInputText('NOM COMMERCIAL :', 'MED_', 'MED_NOMCOMMERCIAL', $ligne[1], 20, 50, 95, true, false) . "<br />\n"
    . formTextArea('COMPOSITION', "MED_COMPOSITION", "MED_CONTREINDIC", $ligne[4], 50, 5, 200, 90, true,false) . "<br />\n"
    . formTextArea('EFFETS', "MED_EFFETS", "MED_CONTREINDIC", $ligne[5], 50, 5, 200, 100, true,false) . "<br />\n"
    . formTextArea('CONTRE INDIC', "MED_CONTREINDIC", "MED_CONTREINDIC", $ligne[2], 50, 5, 200, 110, true,false) . "<br />\n"
    . formInputText('LABORATOIRE :', 'MED_LABO', 'MED_LABO', $ligne[3], 20, 50, 120, true,false);
}

function getInfosPraticien($NumPraticien) {
    $requete = 'SELECT PRA_NOM, PRA_PRENOM, PRA_CP, PRA_ADRESSE, PRA_VILLE, PRA_COEF, TYP_LIBELLE '
            . 'FROM PRATICIEN INNER JOIN TYPE_PRATICIEN ON PRA_TYPE=TYP_CODE '
            . 'WHERE PRA_NUM =' . $NumPraticien;

    $resultat = SGBDConnect()->query($requete);
    $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();

    return formInputText("Nom : :", "PRA_NOM", "PRA_NOM", $ligne[0], 50, 50, 50, true,false) . "<br />\n"
            . formInputText("Prenom :", "PRA_PRENOM", "PRA_PRENOM", $ligne[1], 50, 50, 60, true,false) . "<br />\n"
            . formInputText("Adresse :", "PRA_ADRESSE", "PRA_ADRESSE", $ligne[3], 50, 50, 70, true,false) . "<br />\n"
            . formInputText("Ville :", "PRA_VILLE", "PRA_VILLE", $ligne[2] . ' ' . $ligne[4], 50, 50, 80, true,false) . "<br />\n"
            . formInputText("Coefficient :", "PRA_COEF", "PRA_COEF", $ligne[5], 50, 50, 90, true,false) . "<br />\n"
            . formInputText("Lieu", "PRA_TYPE", "PRA_TYPE", $ligne[6], 50, 50, 100, true,false) . "<br />\n";
}