from tkinter import *
from Include.bibliothèque import *

# personaliser la fenêtre
fenetre = Tk()
fenetre.title('MiniAlexia')
fenetre.minsize(100,100)
fenetre.maxsize(1000,400)


fenetre.geometry('1080x720')
fenetre.config(background='#41B77F')

# creer un frame ( BORDURE4"")


frame = Frame(fenetre, bg='white', bd=1, relief=RAISED)
frame.pack(ipady=30,pady=100, anchor=CENTER) # pady=marge externe axe y, ipady=marge interne

#frameBouton=Frame(fenetre,bg='#41B77F', bd=1 )
#frameBouton.pack(ipadx=40)

#bouton de la case
label_bienvenu = Label(frame, text='MiniAlexia Program', font=("Courrier", 40), bg='white', fg='chartreuse4')
label_bienvenu.grid(row=1, column=0, padx=20)

label_text = Label(frame, text='by Med', font=("Courrier", 12), bg='white', fg='black')
label_text.grid(row=2, column=0)



#boutons de command

Exit_button = Button(frame, text='Exit', font=("Courrier", 20), bg='chartreuse4', fg='white', command=exit)
Exit_button.grid(row=3, column=0, ipadx=40, padx=30)

Wiki_button=Button(fenetre, text='Wikipedia', font=("Courrier", 20), bg='chartreuse4', fg='white', command=definition)
Wiki_button.place(x=40,y=100)

Distance_button=Button(fenetre, text='Itinerary', font=("Courrier", 20), bg='chartreuse4', fg='white', command=distance)
Distance_button.place(x=40,y=180)

adresse_button=Button(fenetre, text='Adress', font=("Courrier", 20), bg='chartreuse4', fg='white', command=adress)
adresse_button.place(x=40,y=250)

Joke_button=Button(fenetre, text='Joke', font=("Courrier", 20), bg='chartreuse4', fg='white', command=joke)
Joke_button.place(x=900,y=100)

Distance_button=Button(fenetre, text='Movie', font=("Courrier", 20), bg='chartreuse4', fg='white', command=movie)
Distance_button.place(x=900,y=180)

Distance_button=Button(fenetre, text='Date', font=("Courrier", 20), bg='chartreuse4', fg='white', command=date)
Distance_button.place(x=900,y=260)



fenetre.mainloop()